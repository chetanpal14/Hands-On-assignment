const form = document.querySelector('form');
const firstNameInput = document.getElementById('first-name');
const lastNameInput = document.getElementById('last-name');
const cityInput = document.getElementById('city');
const addressInput = document.getElementById('address');

form.addEventListener('submit', function(event) {
  event.preventDefault();
  
  if (form.checkValidity()) {
    // Form is valid, proceed with submission
    console.log('Form submitted!');
  } else {
    // Form is invalid, display custom error messages
    if (!firstNameInput.checkValidity()) {
      firstNameInput.setCustomValidity('Please enter your first name.');
    } else {
      firstNameInput.setCustomValidity('');
    }
    
    if (!lastNameInput.checkValidity()) {
      lastNameInput.setCustomValidity('Please enter your last name.');
    } else {
      lastNameInput.setCustomValidity('');
    }
    
    if (!cityInput.checkValidity()) {
      cityInput.setCustomValidity('Please enter your city.');
    } else {
      cityInput.setCustomValidity('');
    }
    
    if (!addressInput.checkValidity()) {
      addressInput.setCustomValidity('Please enter your address.');
    } else {
      addressInput.setCustomValidity('');
    }
    
    form.reportValidity();
  }
});
