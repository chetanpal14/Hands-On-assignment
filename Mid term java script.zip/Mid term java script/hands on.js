document.getElementById('copy').addEventListener('click', function (event) {
  var form1Data = document.getElementById('billingForm');
  var form2Data = document.getElementById('deliveryForm');

  // Copy the values from form1 to form2
  form2Data.firstname.value = form1Data.firstname.value;
  form2Data.lastname.value = form1Data.lastname.value;
  form2Data.address.value = form1Data.address.value;
  form2Data.city.value = form1Data.city.value;
  form2Data.province.value = form1Data.province.value;
  form2Data.zipcode.value = form1Data.zipcode.value;
  form2Data.phone.value = form1Data.phone.value;
});
